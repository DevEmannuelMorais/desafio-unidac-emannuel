package com.emannuel.organizecafe.organizecafe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrganizeCafeApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrganizeCafeApplication.class, args);
	}

}
