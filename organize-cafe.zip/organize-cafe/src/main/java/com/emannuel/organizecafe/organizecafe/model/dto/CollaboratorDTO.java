package com.emannuel.organizecafe.organizecafe.model.dto;

public record CollaboratorDTO(String cpf, String name) {
}
