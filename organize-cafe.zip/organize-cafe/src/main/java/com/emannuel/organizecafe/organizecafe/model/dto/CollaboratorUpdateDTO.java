package com.emannuel.organizecafe.organizecafe.model.dto;

public record CollaboratorUpdateDTO(String cpf, String name) {
}
