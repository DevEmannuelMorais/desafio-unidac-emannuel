package com.emannuel.organizecafe.organizecafe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrganizeCafeApplicationTests {

	@Test
	void contextLoads() {
	}

}
